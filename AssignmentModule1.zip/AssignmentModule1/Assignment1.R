# Step 1: Create a list of 400 workers dynamically
num_workers <- 400
workers <- data.frame(name = character(), salary = numeric(), gender = character(), stringsAsFactors = FALSE)

for (i in 1:num_workers) {
  # Create worker data: name, salary, gender
  name <- paste("Worker", i, sep = "_")
  salary <- 5000 + ((i - 1) %% 30) * 1000  
  gender <- ifelse(i %% 2 == 1, "Male", "Female")  
  
  # Add the worker to the data frame
  workers <- rbind(workers, data.frame(name = name, salary = salary, gender = gender, stringsAsFactors = FALSE))
}

# Step 3: Use a for loop to generate payment slips for each worker
for (i in 1:nrow(workers)) {
  # Step 4: Implement the conditional statements
  if (workers$salary[i] > 10000 && workers$salary[i] < 20000) {
    level <- "A1"
  } else if (workers$salary[i] > 7500 && workers$salary[i] < 30000 && workers$gender[i] == "Female") {
    level <- "A5-F"
  } else {
    level <- "Not Specified"
  }

  # Print the payment slip for each worker
  cat("Payment Slip: Name:", workers$name[i], 
      ", Salary: $", workers$salary[i], 
      ", Gender:", workers$gender[i], 
      ", Level:", level, "\n")
}
